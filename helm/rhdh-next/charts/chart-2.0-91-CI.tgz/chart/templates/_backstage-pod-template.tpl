{{- define "rhdh.backstagePodTemplate" -}}
{{- $root := . -}}
{{- $installDir := "/opt/app-root/src" -}}
{{- $intelligentAssistant := include "rhdh.intelligentAssistant" $root | fromYaml -}}
{{- $extraCatalogImages := include "rhdh.catalogIndex.extraImagesEnvValue" $root | trim -}}
metadata:
  labels:
    {{- include "rhdh.labels" . | nindent 4 }}
    {{- with .Values.podLabels }}
    {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 4 }}
    {{- end }}
  annotations:
    checksum/app-config: {{ include "common.tplvalues.render" (dict "value" .Values.appConfig "context" $) | sha256sum }}
    checksum/dynamic-plugins: {{ include "common.tplvalues.render" (dict "value" (dict "dynamicPlugins" .Values.dynamicPlugins "intelligentAssistant" (dict "enabled" $intelligentAssistant.enabled "plugins" $intelligentAssistant.plugins)) "context" $) | sha256sum }}
    {{- if $intelligentAssistant.enabled }}
    checksum/lightspeed-config: {{ toJson $intelligentAssistant.config | sha256sum }}
    {{- end }}
    {{- with .Values.podAnnotations }}
    {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 4 }}
    {{- end }}
spec:
  serviceAccountName: {{ include "rhdh.serviceAccountName" . }}
  {{- include "rhdh.imagePullSecrets" . | nindent 2 }}
  {{- with .Values.podSecurityContext }}
  securityContext:
    {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 4 }}
  {{- end }}
  {{- with .Values.affinity }}
  affinity:
    {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 4 }}
  {{- end }}
  {{- with .Values.topologySpreadConstraints }}
  topologySpreadConstraints:
    {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 4 }}
  {{- end }}
  {{- with .Values.nodeSelector }}
  nodeSelector:
    {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 4 }}
  {{- end }}
  {{- with .Values.tolerations }}
  tolerations:
    {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 4 }}
  {{- end }}
  {{- with .Values.hostAliases }}
  hostAliases:
    {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 4 }}
  {{- end }}
  volumes:
    # --- System volumes (hardcoded, never replaced) ---
    - name: dynamic-plugins-root
      {{- if eq .Values.dynamicPlugins.volume.type "emptyDir" }}
      emptyDir:
        {{- include "common.tplvalues.render" (dict "value" .Values.dynamicPlugins.volume.emptyDir "context" $) | nindent 8 }}
      {{- else if eq .Values.dynamicPlugins.volume.type "pvc" }}
      persistentVolumeClaim:
        {{- include "common.tplvalues.render" (dict "value" .Values.dynamicPlugins.volume.pvc "context" $) | nindent 8 }}
      {{- else if eq .Values.dynamicPlugins.volume.type "statefulSetPVC" }}
      {{- if ne .Values.workload.kind "StatefulSet" }}
      {{- fail "dynamicPlugins.volume.type=statefulSetPVC requires workload.kind=StatefulSet" }}
      {{- end }}
      persistentVolumeClaim:
        claimName: dynamic-plugins-root
      {{- else if eq .Values.dynamicPlugins.volume.type "ephemeral" }}
      ephemeral:
        volumeClaimTemplate:
          spec:
            {{- $persistence := dict "storageClass" (.Values.dynamicPlugins.volume.ephemeral.storageClassName | default "") }}
            {{- $sc := include "common.storage.class" (dict "persistence" $persistence "global" .Values.global) }}
            {{- if $sc }}
            {{ $sc }}
            {{- end }}
            {{- with .Values.dynamicPlugins.volume.ephemeral.accessModes }}
            accessModes:
              {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 14 }}
            {{- end }}
            {{- with .Values.dynamicPlugins.volume.ephemeral.resources }}
            resources:
              {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 14 }}
            {{- end }}
      {{- end }}
    - name: dynamic-plugins
      configMap:
        defaultMode: 420
        name: {{ printf "%s-dynamic-plugins" (include "rhdh.fullname" .) }}
        optional: true
    - name: dynamic-plugins-npmrc
      secret:
        defaultMode: 420
        optional: true
        secretName: {{ printf "%s-dynamic-plugins-npmrc" (include "rhdh.fullname" .) }}
    - name: dynamic-plugins-registry-auth
      secret:
        defaultMode: 416
        optional: true
        secretName: {{ printf "%s-dynamic-plugins-registry-auth" (include "rhdh.fullname" .) }}
    - name: npmcacache
      emptyDir: {}
    - name: extensions-catalog
      emptyDir: {}
    - name: temp
      emptyDir: {}
    {{- if .Values.appConfig }}
    - name: backstage-app-config
      configMap:
        name: {{ include "rhdh.fullname" . }}-app-config
    {{- end }}
    {{- range .Values.extraAppConfig }}
    - name: {{ .configMapRef }}
      configMap:
        name: {{ .configMapRef }}
    {{- end }}
    {{- if $intelligentAssistant.enabled }}
    - name: lightspeed-data
      {{- if eq $intelligentAssistant.runtimeVolume.type "persistentVolumeClaim" }}
      persistentVolumeClaim:
        {{- include "common.tplvalues.render" (dict "value" $intelligentAssistant.runtimeVolume.persistentVolumeClaim "context" $) | nindent 8 }}
      {{- else }}
      emptyDir:
        {{- include "common.tplvalues.render" (dict "value" $intelligentAssistant.runtimeVolume.emptyDir "context" $) | nindent 8 }}
      {{- end }}
    {{- range $key := list "stack" "profile" }}
    {{- $entry := index $intelligentAssistant.config $key }}
    {{- $cmKey := include "rhdh.intelligentAssistant.configMapKey" (dict "key" $key "entry" $entry) }}
    - name: {{ printf "lightspeed-config-%s" $key }}
      configMap:
        name: {{ include "rhdh.intelligentAssistant.configMapName" (dict "root" $ "key" $key "entry" $entry) }}
        items:
          - key: {{ $cmKey | quote }}
            path: {{ $cmKey | quote }}
    {{- end }}
    {{- end }}
    # --- User-additional volumes (appended) ---
    {{- with .Values.extraVolumes }}
    {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 4 }}
    {{- end }}
  initContainers:
    # --- User pre-init containers (run before system init containers) ---
    {{- with .Values.preInitContainers }}
    {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 4 }}
    {{- end }}
    # --- System init containers (hardcoded) ---
    - name: install-dynamic-plugins
      image: {{ include "rhdh.image" . }}
      imagePullPolicy: {{ .Values.image.pullPolicy | quote }}
      {{- with (.Values.dynamicPlugins.initContainer.securityContext | default .Values.containerSecurityContext) }}
      securityContext:
        {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 8 }}
      {{- end }}
      {{- if .Values.dynamicPlugins.initContainer.commandOverride }}
      command:
        {{- include "common.tplvalues.render" (dict "value" .Values.dynamicPlugins.initContainer.commandOverride "context" $) | nindent 8 }}
      {{- else }}
      command:
        - ./install-dynamic-plugins.sh
        - /dynamic-plugins-root
      {{- end }}
      {{- if .Values.dynamicPlugins.initContainer.argsOverride }}
      args:
        {{- include "common.tplvalues.render" (dict "value" .Values.dynamicPlugins.initContainer.argsOverride "context" $) | nindent 8 }}
      {{- else if .Values.dynamicPlugins.initContainer.extraArgs }}
      args:
        {{- range .Values.dynamicPlugins.initContainer.extraArgs }}
        - {{ . | quote }}
        {{- end }}
      {{- end }}
      env:
        - name: NPM_CONFIG_USERCONFIG
          value: /opt/app-root/src/.npmrc.dynamic-plugins
        - name: MAX_ENTRY_SIZE
          value: {{ .Values.dynamicPlugins.maxEntrySize | int | quote }}
        - name: CATALOG_INDEX_IMAGE
          value: {{ include "rhdh.image.render" (dict "image" .Values.catalogIndex.image "global" .Values.global) | quote }}
        - name: CATALOG_ENTITIES_EXTRACT_DIR
          value: /extensions
        {{- if $extraCatalogImages }}
        - name: EXTRA_CATALOG_INDEX_IMAGES
          value: {{ $extraCatalogImages | quote }}
        {{- end }}
        {{- with .Values.dynamicPlugins.initContainer.extraEnv }}
        {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 8 }}
        {{- end }}
      {{- with .Values.dynamicPlugins.initContainer.resources }}
      resources:
        {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 8 }}
      {{- end }}
      volumeMounts:
        - mountPath: /dynamic-plugins-root
          name: dynamic-plugins-root
        - mountPath: /opt/app-root/src/dynamic-plugins.yaml
          name: dynamic-plugins
          readOnly: true
          subPath: dynamic-plugins.yaml
        - mountPath: /opt/app-root/src/.npmrc.dynamic-plugins
          name: dynamic-plugins-npmrc
          readOnly: true
          subPath: .npmrc
        - mountPath: /opt/app-root/src/.config/containers
          name: dynamic-plugins-registry-auth
          readOnly: true
        - mountPath: /opt/app-root/src/.npm/_cacache
          name: npmcacache
        - name: extensions-catalog
          mountPath: /extensions
        - name: temp
          mountPath: /tmp
        {{- with .Values.dynamicPlugins.initContainer.extraVolumeMounts }}
        {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 8 }}
        {{- end }}
      workingDir: /opt/app-root/src
    {{- if or .Values.postgresql.enabled .Values.externalDatabase.host }}
    - name: wait-for-db
      image: {{ include "rhdh.image.render" (dict "image" .Values.postgresql.image "global" .Values.global) | quote }}
      imagePullPolicy: {{ .Values.postgresql.image.pullPolicy | default "IfNotPresent" | quote }}
      securityContext:
        readOnlyRootFilesystem: true
        allowPrivilegeEscalation: false
        runAsNonRoot: true
        capabilities:
          drop:
            - ALL
      resources:
        limits:
          cpu: "100m"
          memory: "64Mi"
        requests:
          cpu: "50m"
          memory: "32Mi"
      command:
        - bash
        - -c
        - |
          dbHost={{ include "rhdh.postgresql.host" . | quote }}
          dbPort={{ .Values.externalDatabase.port | default 5432 | quote }}
          echo "Waiting for DB at $dbHost:$dbPort..."
          until timeout 2 bash -c ">/dev/tcp/$dbHost/$dbPort" 2>/dev/null; do
            sleep 2
          done
          echo "DB is reachable!"
    {{- end }}
    # --- User-additional init containers (appended) ---
    {{- with .Values.extraInitContainers }}
    {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 4 }}
    {{- end }}
  containers:
    - name: backstage-backend
      image: {{ include "rhdh.image" . }}
      imagePullPolicy: {{ .Values.image.pullPolicy | quote }}
      {{- with .Values.containerSecurityContext }}
      securityContext:
        {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 8 }}
      {{- end }}
      {{- if .Values.commandOverride }}
      command:
        {{- include "common.tplvalues.render" (dict "value" .Values.commandOverride "context" $) | nindent 8 }}
      {{- end }}
      args:
        {{- if .Values.argsOverride }}
        {{- range .Values.argsOverride }}
        - {{ . | quote }}
        {{- end }}
        {{- else }}
        - "--config"
        - "{{ $installDir }}/dynamic-plugins-root/app-config.dynamic-plugins.yaml"
        {{- if .Values.appConfig }}
        - "--config"
        - "{{ $installDir }}/app-config-from-configmap.yaml"
        {{- end }}
        {{- range .Values.extraAppConfig }}
        - "--config"
        - "{{ $installDir }}/{{ .filename }}"
        {{- end }}
        {{- range .Values.extraArgs }}
        - {{ . | quote }}
        {{- end }}
        {{- end }}
      {{- with .Values.resources }}
      resources:
        {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 8 }}
      {{- end }}
      {{- with .Values.startupProbe }}
      startupProbe:
        {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 8 }}
      {{- end }}
      {{- with .Values.readinessProbe }}
      readinessProbe:
        {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 8 }}
      {{- end }}
      {{- with .Values.livenessProbe }}
      livenessProbe:
        {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 8 }}
      {{- end }}
      {{- if or .Values.envFromOverride .Values.extraEnvFrom }}
      envFrom:
        {{- if .Values.envFromOverride }}
        {{- include "common.tplvalues.render" (dict "value" .Values.envFromOverride "context" $) | nindent 8 }}
        {{- else }}
        {{- include "common.tplvalues.render" (dict "value" .Values.extraEnvFrom "context" $) | nindent 8 }}
        {{- end }}
      {{- end }}
      env:
        {{- if .Values.envOverride }}
        {{- include "common.tplvalues.render" (dict "value" .Values.envOverride "context" $) | nindent 8 }}
        {{- else }}
        # --- System env vars (hardcoded) ---
        - name: APP_CONFIG_backend_listen_port
          value: {{ .Values.service.port | quote }}
        {{- if .Values.auth.backend.enabled }}
        - name: BACKEND_SECRET
          valueFrom:
            secretKeyRef:
              name: {{ include "rhdh.backend-secret-name" . }}
              key: {{ include "rhdh.backend-secret-key" . }}
        {{- end }}
        {{- if .Values.postgresql.enabled }}
        - name: POSTGRES_HOST
          value: {{ include "rhdh.postgresql.host" . }}
        - name: POSTGRES_PORT
          value: "5432"
        - name: POSTGRES_USER
          value: {{ .Values.postgresql.auth.username | default "postgres" }}
        - name: POSTGRES_PASSWORD
          valueFrom:
            secretKeyRef:
              name: {{ include "rhdh.postgresql.secretName" . }}
              key: {{ include "rhdh.postgresql.adminPasswordKey" . }}
        {{- else if .Values.externalDatabase.host }}
        - name: POSTGRES_HOST
          value: {{ .Values.externalDatabase.host | quote }}
        - name: POSTGRES_PORT
          value: {{ .Values.externalDatabase.port | quote }}
        - name: POSTGRES_USER
          value: {{ .Values.externalDatabase.user | default "postgres" | quote }}
        - name: POSTGRES_PASSWORD
          valueFrom:
            secretKeyRef:
              name: {{ required "externalDatabase.existingSecretRef.name is required when externalDatabase.host is set" .Values.externalDatabase.existingSecretRef.name }}
              key: {{ .Values.externalDatabase.existingSecretRef.key | default "password" }}
        {{- end }}
        # --- User-additional env vars (appended) ---
        {{- with .Values.extraEnv }}
        {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 8 }}
        {{- end }}
        {{- end }}
      ports:
        - name: backend
          containerPort: {{ .Values.service.port }}
          protocol: TCP
      volumeMounts:
        # --- System volume mounts (hardcoded) ---
        - mountPath: {{ $installDir }}/dynamic-plugins-root
          name: dynamic-plugins-root
        - name: extensions-catalog
          mountPath: /extensions
        - name: temp
          mountPath: /tmp
        {{- if .Values.appConfig }}
        - name: backstage-app-config
          mountPath: "{{ $installDir }}/app-config-from-configmap.yaml"
          subPath: app-config.yaml
        {{- end }}
        {{- range .Values.extraAppConfig }}
        - name: {{ .configMapRef }}
          mountPath: "{{ $installDir }}/{{ .filename }}"
          subPath: {{ .filename }}
        {{- end }}
        # --- User-additional volume mounts (appended) ---
        {{- with .Values.extraVolumeMounts }}
        {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 8 }}
        {{- end }}
    {{- if $intelligentAssistant.enabled }}
    - name: lightspeed-core
      image: {{ include "rhdh.image.render" (dict "image" $intelligentAssistant.core.image "global" .Values.global) | quote }}
      imagePullPolicy: {{ $intelligentAssistant.core.imagePullPolicy | quote }}
      {{- with $intelligentAssistant.core.securityContext }}
      securityContext:
        {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 8 }}
      {{- end }}
      {{- if $intelligentAssistant.core.commandOverride }}
      command:
        {{- include "common.tplvalues.render" (dict "value" $intelligentAssistant.core.commandOverride "context" $) | nindent 8 }}
      {{- else if and (include "rhdh.intelligentAssistant.okp.active" $) (not $intelligentAssistant.core.argsOverride) }}
      command: ["/bin/sh", "-c"]
      {{- end }}
      {{- if $intelligentAssistant.core.argsOverride }}
      args:
        {{- include "common.tplvalues.render" (dict "value" $intelligentAssistant.core.argsOverride "context" $) | nindent 8 }}
      {{- else if and (include "rhdh.intelligentAssistant.okp.active" $) (not $intelligentAssistant.core.commandOverride) }}
      args:
        - |
          if [ -f /var/run/secrets/kubernetes.io/serviceaccount/ca.crt ]; then
            cat /etc/pki/tls/certs/ca-bundle.crt /var/run/secrets/kubernetes.io/serviceaccount/ca.crt > /tmp/combined-ca-bundle.crt
            export SSL_CERT_FILE=/tmp/combined-ca-bundle.crt
            export REQUESTS_CA_BUNDLE=/tmp/combined-ca-bundle.crt
          fi
          exec /app-root/entrypoint.sh --synthesized-config-output /tmp/.generated/run.yaml{{ range $intelligentAssistant.core.extraArgs }} {{ . | quote }}{{ end }}
      {{- else }}
      args:
        - "--synthesized-config-output"
        - "/tmp/.generated/run.yaml"
        {{- range $intelligentAssistant.core.extraArgs }}
        - {{ . | quote }}
        {{- end }}
      {{- end }}
      ports:
        - name: http-lightspeed
          containerPort: 8080
          protocol: TCP
      {{- if $intelligentAssistant.existingSecret }}
      envFrom:
        - secretRef:
            name: {{ $intelligentAssistant.existingSecret }}
      {{- end }}
      env:
        {{- if include "rhdh.intelligentAssistant.okp.active" $ }}
        - name: OKP_SERVICE_URL
          value: {{ include "rhdh.intelligentAssistant.okp.serviceUrl" $ | quote }}
        {{- end }}
        - name: KV_STORE_PATH
          value: "/tmp/kvstore.db"
        - name: SQL_STORE_PATH
          value: "/tmp/sql_store.db"
        - name: SQLITE_STORE_DIR
          value: "/tmp/llama-stack-files"
        - name: HF_HOME
          value: "/tmp/hf_cache"
        - name: OTEL_SDK_DISABLED
          value: "true"
        {{- with $intelligentAssistant.core.extraEnv }}
        {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 8 }}
        {{- end }}
      {{- with $intelligentAssistant.core.resources }}
      resources:
        {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 8 }}
      {{- end }}
      volumeMounts:
        - name: lightspeed-data
          mountPath: "/tmp"
        {{- range $key := list "stack" "profile" }}
        {{- $entry := index $intelligentAssistant.config $key }}
        {{- $file := include "rhdh.intelligentAssistant.configFile" $key }}
        {{- $cmKey := include "rhdh.intelligentAssistant.configMapKey" (dict "key" $key "entry" $entry) }}
        - name: {{ printf "lightspeed-config-%s" $key }}
          mountPath: {{ printf "/app-root/%s" $file | quote }}
          subPath: {{ $cmKey | quote }}
          readOnly: true
        {{- end }}
        {{- with $intelligentAssistant.core.extraVolumeMounts }}
        {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 8 }}
        {{- end }}
    {{- end }}
    # --- User-additional sidecar containers (appended) ---
    {{- with .Values.extraContainers }}
    {{- include "common.tplvalues.render" (dict "value" . "context" $) | nindent 4 }}
    {{- end }}
{{- end -}}
