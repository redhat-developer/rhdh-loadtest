{{/*
Expand the name of the chart.
*/}}
{{- define "rhdh.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "rhdh.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "rhdh.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "rhdh.labels" -}}
helm.sh/chart: {{ include "rhdh.chart" . }}
{{ include "rhdh.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.commonLabels }}
{{ include "common.tplvalues.render" (dict "value" . "context" $) }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "rhdh.selectorLabels" -}}
app.kubernetes.io/name: {{ include "rhdh.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: backstage
{{- end }}

{{- define "rhdh.statefulSetHeadlessServiceName" -}}
{{- printf "%s-headless" (include "rhdh.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "rhdh.statefulSetServiceName" -}}
{{- default (include "rhdh.statefulSetHeadlessServiceName" .) .Values.workload.statefulSet.serviceName -}}
{{- end -}}

{{/*
Create the name of the service account to use.
*/}}
{{- define "rhdh.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "rhdh.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Return the backstage image string, respecting global.imageRegistry.
*/}}
{{- define "rhdh.image" -}}
{{- include "common.images.image" (dict "imageRoot" .Values.image "global" .Values.global "chart" .Chart) -}}
{{- end -}}

{{/*
Return an image reference from a value that may be a string or a map with registry/repository/tag fields.
When the value is a map, global.imageRegistry is applied via the bitnami common helper.
*/}}
{{- define "rhdh.image.render" -}}
{{- if kindIs "string" .image -}}
  {{- .image -}}
{{- else -}}
  {{- include "common.images.image" (dict "imageRoot" (.image | toYaml | fromYaml) "global" .global) -}}
{{- end -}}
{{- end -}}

{{/*
Merge global.imagePullSecrets and imagePullSecrets into a single imagePullSecrets block.
*/}}
{{- define "rhdh.imagePullSecrets" -}}
{{- $secrets := list -}}
{{- range ((.Values.global).imagePullSecrets) -}}
  {{- if kindIs "map" . -}}
    {{- $secrets = append $secrets .name -}}
  {{- else -}}
    {{- $secrets = append $secrets . -}}
  {{- end -}}
{{- end -}}
{{- range .Values.imagePullSecrets -}}
  {{- if kindIs "map" . -}}
    {{- $secrets = append $secrets .name -}}
  {{- else -}}
    {{- $secrets = append $secrets . -}}
  {{- end -}}
{{- end -}}
{{- if $secrets }}
imagePullSecrets:
  {{- range $secrets | uniq }}
  - name: {{ . }}
  {{- end }}
{{- end -}}
{{- end -}}

{{/*
Returns custom hostname.
*/}}
{{- define "rhdh.hostname" -}}
    {{- if .Values.host -}}
        {{- .Values.host -}}
    {{- else if .Values.openshift.clusterRouterBase -}}
        {{- printf "%s-%s.%s" (include "rhdh.fullname" .) .Release.Namespace .Values.openshift.clusterRouterBase -}}
    {{- else -}}
        {{ fail "Unable to generate hostname: set host or openshift.clusterRouterBase" }}
    {{- end -}}
{{- end -}}

{{/*
Returns the Secret name for service-to-service auth.
*/}}
{{- define "rhdh.backend-secret-name" -}}
    {{- if .Values.auth.backend.existingSecretRef.name -}}
        {{- .Values.auth.backend.existingSecretRef.name -}}
    {{- else -}}
        {{- printf "%s-auth" (include "rhdh.fullname" .) -}}
    {{- end -}}
{{- end -}}

{{/*
Returns the Secret key for service-to-service auth.
*/}}
{{- define "rhdh.backend-secret-key" -}}
    {{- .Values.auth.backend.existingSecretRef.key | default "backend-secret" -}}
{{- end -}}

{{/*
Returns the PostgreSQL secret name.
*/}}
{{- define "rhdh.postgresql.secretName" -}}
    {{- if ((((.Values).postgresql).auth).existingSecret) -}}
        {{- .Values.postgresql.auth.existingSecret -}}
    {{- else -}}
        {{- printf "%s-%s" .Release.Name "postgresql" -}}
    {{- end -}}
{{- end -}}

{{/*
Returns the PostgreSQL admin password key.
*/}}
{{- define "rhdh.postgresql.adminPasswordKey" -}}
    {{- if (((((.Values).postgresql).auth).secretKeys).adminPasswordKey) -}}
        {{- .Values.postgresql.auth.secretKeys.adminPasswordKey -}}
    {{- else -}}
        postgres-password
    {{- end -}}
{{- end -}}

{{/*
Returns the PostgreSQL hostname.
When postgresql.enabled is false, returns externalDatabase.host.
When enabled, appends -primary when postgresql.architecture is "replication".
*/}}
{{- define "rhdh.postgresql.host" -}}
{{- if not .Values.postgresql.enabled -}}
{{- .Values.externalDatabase.host -}}
{{- else if eq (default "standalone" .Values.postgresql.architecture) "replication" -}}
{{- printf "%s-postgresql-primary" .Release.Name -}}
{{- else -}}
{{- printf "%s-postgresql" .Release.Name -}}
{{- end -}}
{{- end -}}

{{/*
Return resolved Intelligent Assistant values from .Values.intelligentAssistant with validation.
*/}}
{{- define "rhdh.intelligentAssistant" -}}
{{- $intelligentAssistant := deepCopy .Values.intelligentAssistant -}}
{{- if $intelligentAssistant.enabled -}}
  {{- $volType := default "emptyDir" $intelligentAssistant.runtimeVolume.type -}}
  {{- if and (ne $volType "emptyDir") (ne $volType "persistentVolumeClaim") -}}
    {{- fail "intelligentAssistant.runtimeVolume.type must be emptyDir or persistentVolumeClaim" -}}
  {{- end -}}
  {{- if eq $volType "persistentVolumeClaim" -}}
    {{- if or (not (kindIs "map" $intelligentAssistant.runtimeVolume.persistentVolumeClaim)) (empty $intelligentAssistant.runtimeVolume.persistentVolumeClaim.claimName) -}}
      {{- fail "intelligentAssistant.runtimeVolume.persistentVolumeClaim.claimName is required when type=persistentVolumeClaim" -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- toYaml $intelligentAssistant -}}
{{- end -}}

{{/*
Return the bundled filename for an Intelligent Assistant config key.
*/}}
{{- define "rhdh.intelligentAssistant.configFile" -}}
{{- $map := dict "stack" "lightspeed-stack.yaml" "profile" "rhdh-profile.py" -}}
{{- get $map . | required (printf "unknown intelligentAssistant config key: %s" .) -}}
{{- end -}}

{{/*
Return the Intelligent Assistant ConfigMap name for a given key.
If existingConfigMap.name is set, use it; otherwise generate from release name.
Expects: dict "root" $ "key" <key> "entry" <config entry>

Kubernetes names are limited to 63 characters. Using the infix "-ia-" (Intelligent
Assistant) instead of "-intelligent-assistant-" leaves more of the fullname intact.
Still truncate the fullname prefix (not the whole string) so "-ia-stack" and
"-ia-profile" are never chopped off the right side — Helm's `trunc 63` would
otherwise make those names collide when fullname is long.
*/}}
{{- define "rhdh.intelligentAssistant.configMapName" -}}
{{- if .entry.existingConfigMap.name -}}
  {{- .entry.existingConfigMap.name -}}
{{- else -}}
  {{- $suffix := printf "-ia-%s" .key -}}
  {{- $maxPrefix := int (sub 63 (len $suffix)) -}}
  {{- $prefix := include "rhdh.fullname" .root | trunc $maxPrefix | trimSuffix "-" -}}
  {{- printf "%s%s" $prefix $suffix -}}
{{- end -}}
{{- end -}}

{{/*
Return the key to use for an Intelligent Assistant ConfigMap volume mount.
If existingConfigMap.key is set, use it; otherwise use the bundled filename.
Expects: dict "key" <key> "entry" <config entry>
*/}}
{{- define "rhdh.intelligentAssistant.configMapKey" -}}
{{- if .entry.existingConfigMap.key -}}
  {{- .entry.existingConfigMap.key -}}
{{- else -}}
  {{- include "rhdh.intelligentAssistant.configFile" .key -}}
{{- end -}}
{{- end -}}


{{/*
Return the computed EXTRA_CATALOG_INDEX_IMAGES env var value.
*/}}
{{- define "rhdh.catalogIndex.extraImagesEnvValue" -}}
{{- $root := . -}}
{{- $imgs := list -}}
{{- range (.Values.catalogIndex.extraImages | default list) -}}
  {{- $item := include "common.tplvalues.render" (dict "value" . "context" $root) | fromYaml -}}
  {{- $ref := include "rhdh.image.render" (dict "image" $item "global" $root.Values.global) -}}
  {{- if $item.name -}}
    {{- if or (contains "," $item.name) (contains "=" $item.name) -}}
      {{- fail (printf "catalogIndex.extraImages[].name %q must not contain ',' or '='" $item.name) -}}
    {{- end -}}
    {{- $ref = printf "%s=%s" $item.name $ref -}}
  {{- end -}}
  {{- $imgs = append $imgs $ref -}}
{{- end -}}
{{- join "," $imgs -}}
{{- end -}}

{{/*
Return an orchestrator image, resolving tpl expressions in each field.
Expects: dict "image" <image map> "context" $
*/}}
{{- define "rhdh.orchestrator.image" -}}
{{- $resolved := dict
  "registry" (tpl (default "" .image.registry) .context)
  "repository" (tpl (default "" .image.repository) .context)
  "tag" (tpl (default "" .image.tag) .context)
  "digest" (tpl (default "" .image.digest) .context)
-}}
{{- include "rhdh.image.render" (dict "image" $resolved "global" .context.Values.global) -}}
{{- end -}}

{{/*
Return true if any field in a structured image map is non-empty.
Expects: an image map with registry/repository/tag/digest fields.
*/}}
{{- define "rhdh.image.hasOverride" -}}
{{- if or .registry .repository .tag .digest -}}true{{- end -}}
{{- end -}}

{{/*
Returns the orchestrator DB creation Job name, lowercased and truncated to 63 chars.
The version suffix is preserved in full; only the prefix is truncated.
*/}}
{{- define "rhdh.orchestrator.dbJobName" -}}
{{- $versionSuffix := printf "-%s" (.Chart.Version | replace "." "-") -}}
{{- $prefix := printf "%s-create-sf-db" (include "rhdh.fullname" .) | trunc (int (sub 63 (len $versionSuffix))) | trimSuffix "-" -}}
{{- printf "%s%s" $prefix $versionSuffix | lower -}}
{{- end -}}

{{/*
Merge global.imagePullSecrets and intelligentAssistant.okp.imagePullSecrets into a single block.
*/}}
{{- define "rhdh.intelligentAssistant.okp.imagePullSecrets" -}}
{{- $ia := include "rhdh.intelligentAssistant" . | fromYaml -}}
{{- $secrets := list -}}
{{- range ((.Values.global).imagePullSecrets) -}}
  {{- if kindIs "map" . -}}
    {{- $secrets = append $secrets .name -}}
  {{- else -}}
    {{- $secrets = append $secrets . -}}
  {{- end -}}
{{- end -}}
{{- range $ia.okp.imagePullSecrets -}}
  {{- $secrets = append $secrets . -}}
{{- end -}}
{{- if $secrets }}
imagePullSecrets:
  {{- range $secrets | uniq }}
  - name: {{ . }}
  {{- end }}
{{- end -}}
{{- end -}}

{{/*
Return whether OKP should be deployed.
OKP must be explicitly enabled on every platform.
On OpenShift (openshift.route.enabled): also requires okp.route.enabled.
On vanilla K8s: also requires okp.ingress.enabled and a non-empty okp.ingress.host.
*/}}
{{- define "rhdh.intelligentAssistant.okp.active" -}}
{{- $ia := include "rhdh.intelligentAssistant" . | fromYaml -}}
{{- if and $ia.enabled $ia.okp.enabled (or (and .Values.openshift.route.enabled $ia.okp.route.enabled) (and (not .Values.openshift.route.enabled) $ia.okp.ingress.enabled $ia.okp.ingress.host)) -}}
true
{{- end -}}
{{- end -}}

{{/*
Return the OKP deployment/service/route name.
*/}}
{{- define "rhdh.intelligentAssistant.okp.fullname" -}}
{{- printf "%s-ia-okp" (include "rhdh.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Return OKP labels.
*/}}
{{- define "rhdh.intelligentAssistant.okp.labels" -}}
{{ include "rhdh.labels" . }}
app.kubernetes.io/component: intelligent-assistant-okp
{{- end -}}

{{/*
Return OKP selector labels.
*/}}
{{- define "rhdh.intelligentAssistant.okp.selectorLabels" -}}
app.kubernetes.io/name: {{ include "rhdh.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: intelligent-assistant-okp
{{- end -}}

{{/*
Return the OKP service URL for the OKP_SERVICE_URL env var.
When openshift.route.enabled is false and OKP Ingress is enabled with a host: uses the Ingress host.
When openshift.clusterRouterBase is set: uses the Route URL (HTTPS, verified via the
combined CA bundle prepared by the prepare-ca-bundle init container).
Fallback: cluster-internal service URL (backend-only; citation links will not be
externally routable in this case).
*/}}
{{- define "rhdh.intelligentAssistant.okp.serviceUrl" -}}
{{- $ia := include "rhdh.intelligentAssistant" . | fromYaml -}}
{{- $fullname := include "rhdh.intelligentAssistant.okp.fullname" . -}}
{{- if and (not .Values.openshift.route.enabled) $ia.okp.ingress.host -}}
  {{- if $ia.okp.ingress.tls.enabled -}}
    {{- printf "https://%s" $ia.okp.ingress.host -}}
  {{- else -}}
    {{- printf "http://%s" $ia.okp.ingress.host -}}
  {{- end -}}
{{- else if .Values.openshift.clusterRouterBase -}}
  {{- printf "https://%s-%s.%s" $fullname .Release.Namespace .Values.openshift.clusterRouterBase -}}
{{- else -}}
  {{- printf "http://%s.%s.svc.cluster.local:8080" $fullname .Release.Namespace -}}
{{- end -}}
{{- end -}}
